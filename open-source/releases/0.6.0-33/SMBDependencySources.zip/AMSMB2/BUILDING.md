# Build the bundled dynamic library

The archive contains the exact AMSMB2 and libsmb2 source used by this build,
including original notices. Local Package.swift omits Linux-only dependencies
and upstream tests; runtime source is unchanged.

With Xcode and the visionOS SDK installed:

```sh
xcodebuild -scheme AMSMB2 -destination 'generic/platform=visionOS' -configuration Release -derivedDataPath /tmp/AMSMB2-Rebuild CODE_SIGNING_ALLOWED=NO build
```

For simulator use `generic/platform=visionOS Simulator`. The product is dynamic.
Changes can be built from these sources and the library replaced in a locally
signed App bundle. Re-sign with your own development identity; no Ensceno
private keys or credentials are needed or provided in this archive.
