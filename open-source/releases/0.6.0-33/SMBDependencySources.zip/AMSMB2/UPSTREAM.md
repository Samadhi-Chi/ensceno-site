# Vendored SMB dependency

Source: https://github.com/amosavian/AMSMB2
Commit: `90737c486c9d1a6ed1c1d4307060587c7bb0dfec`
libsmb2: https://github.com/sahlberg/libsmb2
Commit: `aedafb2c8742c83188e27841e270fdaad6035d41`

Local packaging: retain the dynamic AMSMB2 product; omit upstream tests and Darwin-unused swift-system / swift-atomics package dependencies. Runtime source is unchanged. Original licenses are preserved.
