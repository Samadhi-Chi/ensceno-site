#!/usr/bin/env python3
"""Prepare a separate, unsigned Ensceno copy with an ABI-compatible SMB library.

This does not install an app, sign with a developer identity, or alter its input.
Use the unencrypted release materials, not a FairPlay-encrypted store download.
"""

import argparse
import json
import plistlib
import re
import shutil
import subprocess
from pathlib import Path


def output(*args):
    return subprocess.check_output(args, text=True)


def exports(binary):
    return set(output("xcrun", "nm", "-gjU", str(binary)).splitlines())


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--app", type=Path, required=True)
    parser.add_argument("--framework", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--bundle-id", help="Optional ID for your own development profile")
    args = parser.parse_args()
    app, framework, destination = (p.resolve() for p in (args.app, args.framework, args.output))
    if destination.exists() or destination.suffix != ".app":
        parser.error("Output must be a new .app path; existing data is never overwritten.")
    if app in destination.parents or framework in destination.parents:
        parser.error("Output must be outside both input bundles.")
    if args.bundle_id and not re.fullmatch(r"[A-Za-z0-9-]+(?:\.[A-Za-z0-9-]+)+", args.bundle_id):
        parser.error("Bundle ID must use dot-separated alphanumeric/hyphen components.")

    info = plistlib.loads((app / "Info.plist").read_bytes())
    executable = info["CFBundleExecutable"]
    if Path(executable).name != executable:
        parser.error("Invalid executable name.")
    binary = app / executable
    load_commands = output("xcrun", "otool", "-l", str(binary))
    crypt_ids = re.findall(r"cryptid\s+(\d+)", load_commands)
    if not crypt_ids or any(value != "0" for value in crypt_ids):
        parser.error("Use the provided unencrypted visionOS release bundle.")
    if "@rpath/AMSMB2.framework/AMSMB2" not in load_commands:
        parser.error("The app does not dynamically load the expected SMB library.")

    replacement_binary = framework / "AMSMB2"
    replacement_loads = output("xcrun", "otool", "-l", str(replacement_binary))
    if not re.search(r"platform\s+(11|XROS)\b", replacement_loads):
        parser.error("Replacement must target a visionOS device, not the Simulator.")
    if "@rpath/AMSMB2.framework/AMSMB2" not in replacement_loads:
        parser.error("Replacement must preserve the library's install name.")
    original_framework = app / "Frameworks" / "AMSMB2.framework"
    missing = exports(original_framework / "AMSMB2") - exports(replacement_binary)
    if missing:
        parser.error(f"Replacement is missing {len(missing)} original exported symbols.")

    shutil.copytree(app, destination)
    target_framework = destination / "Frameworks" / "AMSMB2.framework"
    shutil.rmtree(target_framework)
    shutil.copytree(framework, target_framework)
    for bundle in (target_framework, destination):
        # Remove signatures only from newly created output, never from input files.
        subprocess.run(["codesign", "--remove-signature", str(bundle)],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, check=False)
        signature = bundle / "_CodeSignature"
        if signature.exists():
            shutil.rmtree(signature)
    for profile in destination.rglob("*.mobileprovision"):
        profile.unlink()
    if args.bundle_id:
        info["CFBundleIdentifier"] = args.bundle_id
        (destination / "Info.plist").write_bytes(plistlib.dumps(info))
    print(json.dumps({"output": str(destination), "bundleID": info["CFBundleIdentifier"],
                      "missingExports": 0, "signed": False, "installed": False}, indent=2))


if __name__ == "__main__":
    main()
